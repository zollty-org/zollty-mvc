package com.zolltymvc.demo;

import javax.servlet.http.HttpServletRequest;

import org.zollty.framework.mvc.View;
import org.zollty.framework.mvc.annotation.Controller;
import org.zollty.framework.mvc.annotation.RequestMapping;
import org.zollty.framework.mvc.view.JspView;

@Controller
public class HelloController {
	
	@RequestMapping(value = "/hello")
	public View index(HttpServletRequest request) {
        request.setAttribute("hello", "Welcome to use ZolltyMVC! See more: http://code.google.com/p/zollty-mvc/ ");
        return new JspView("/hello.jsp");
	}
}
